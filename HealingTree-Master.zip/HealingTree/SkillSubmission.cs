﻿
using System.Collections;
using ThunderRoad;
using UnityEngine;

namespace HealingTree
{
    public class SkillSubmission : SkillData
    {
        public LiquidData data;
        public ItemData potion;
        public override void OnSkillLoaded(SkillData skillData, Creature creature)
        {
            base.OnSkillLoaded(skillData, creature);
            Debug.Log("Nuts");
        }
    }
}
