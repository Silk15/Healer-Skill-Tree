﻿
using System.Collections;
using ThunderRoad;
using UnityEngine;

namespace HealingTree
{
    public class PotionMono : MonoBehaviour
    {
        public void Start()
        {
            Debug.Log("Hello");
        }

    }
}
