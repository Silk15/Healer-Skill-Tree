﻿
using System.Collections;
using ThunderRoad;
using ThunderRoad.Skill;
using ThunderRoad.Skill.Spell;
using UnityEngine;

namespace HealingTree
{
    public class SkillTherapy : SpellSkillData
    {
    }
}
