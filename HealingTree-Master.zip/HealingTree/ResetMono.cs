﻿
using System.Collections;
using ThunderRoad;
using UnityEngine;

namespace HealingTree
{
    public class ResetMono : MonoBehaviour
    {
        public void Start()
        {
            Debug.Log("Hello");
        }

    }
}
