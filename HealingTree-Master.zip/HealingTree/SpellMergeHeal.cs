﻿
using UnityEngine;
using ThunderRoad;
using ThunderRoad.Skill;

namespace HealingTree
{
    public class SpellMergeHeal : SpellMergeData 
    {
        public bool isCasting;
        EffectInstance effect;
        public float healing = 7;
        public float healingRadius = 3;
        public override void Merge(bool active)
        {
            base.Merge(active);
            isCasting = active;
        }
        public override void FixedUpdate()
        {
            base.FixedUpdate();
            if (isCasting)
            {
                Collider[] sphereContacts = Physics.OverlapSphere(Player.local.transform.position, healingRadius);
                foreach (Collider collider in sphereContacts)
                {
                    var creature = collider?.GetComponentInParent<Creature>();
                    creature?.Heal(healing * Time.fixedDeltaTime);
                }
            }
        }
    }
}
