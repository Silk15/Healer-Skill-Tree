﻿
using System.Collections;
using ThunderRoad;
using UnityEngine;

namespace HealingTree
{
    public class SkillEnhancedConstitution : SkillData
    {
        public bool buffActive = false;
        public override void OnSkillLoaded(SkillData skillData, Creature creature)
        {
            base.OnSkillLoaded(skillData, creature);
            EventManager.onLiquidConsumed += EventManager_onLiquidConsumed;
        }
        public override void OnSkillUnloaded(SkillData skillData, Creature creature)
        {
            base.OnSkillUnloaded(skillData, creature);
            EventManager.onLiquidConsumed -= EventManager_onLiquidConsumed;
        }
        private void EventManager_onLiquidConsumed(LiquidContainer liquidContainer, Creature consumer, EventTime eventTime)
        {
            if (consumer.isPlayer && !buffActive && eventTime == EventTime.OnEnd)
            {
                buffActive = true;
                Catalog.GetData<EffectData>("HitImbueHealer").Spawn(liquidContainer.item.GetComponentInChildren<Holder>().transform);
                GameManager.local.StartCoroutine(DisableBuff());
                GameManager.local.StartCoroutine(HealWhile());
            }
        }
        IEnumerator DisableBuff()
        {
            yield return new WaitForSeconds(30);
            buffActive = false;
        }
        IEnumerator HealWhile()
        {
            yield return new WaitForSeconds(0.01f);
            while (buffActive)
            {
                yield return new WaitForSeconds(1);
                Player.currentCreature.Heal(2.5f);
            }
        }
    }
}
