﻿
using System;
using System.Collections;
using ThunderRoad;
using ThunderRoad.Skill;
using UnityEngine;

namespace HealingTree
{
    public class SkillDocsFury : SkillData
    {
        protected EffectData startEffectData;
        public override void OnSkillLoaded(SkillData skillData, Creature creature)
        {
            base.OnSkillLoaded(skillData, creature);
            EventManager.onCreatureKill += EventManager_onCreatureKill;
            startEffectData = Catalog.GetData<EffectData>("SecondWindStart");
        }
        public override void OnSkillUnloaded(SkillData skillData, Creature creature)
        {
            base.OnSkillUnloaded(skillData, creature);
            EventManager.onCreatureKill -= EventManager_onCreatureKill;
        }
        private void EventManager_onCreatureKill(Creature creature, Player player, CollisionInstance collisionInstance, EventTime eventTime)
        {
            if (!creature.isPlayer && creature.factionId == 2 && eventTime == EventTime.OnEnd)
            {
                GameManager.local.StartCoroutine(Fury());
            }
        }
        IEnumerator Fury()
        {
            GameManager.local.StartCoroutine(SepiaRoutine(0.0f, 1f, 0.3f));
            yield return new WaitForSeconds(0.5f);
            Player.currentCreature.mana.GetPowerSlowTime()?.Activate(false);
            CameraEffects.ClearAllSepia();
            Player.currentCreature.SetDamageMultiplier(this, 0.5f);
            Player.currentCreature.SetDamageMultiplier(this, 10);
            Player.currentCreature.AddJointForceMultiplier(this, 10, 10);

            Player.currentCreature.currentLocomotion.SetAllSpeedModifiers(this, 1.3f);
            Player.currentCreature.Heal(Player.currentCreature.maxHealth);
            Player.invincibility = true;
            TimeManager.SetSlowMotion(false, 1f, AnimationCurve.Linear(0.0f, 0.0f, 1f, 1f));
            EffectInstance startEffect = startEffectData.Spawn(Player.currentCreature.ragdoll.targetPart.transform);
            yield return new WaitForSeconds(10);
            Player.currentCreature.RemoveDamageMultiplier(this);
            Player.currentCreature.RemoveJointForceMultiplier(this);
            Player.currentCreature.currentLocomotion.RemoveSpeedModifier(this);
            Player.invincibility = false;
            startEffect?.End();
        }
        public IEnumerator SepiaRoutine(float start, float end, float time)
        {
            SkillDocsFury handler = this;
            float startTime = Time.realtimeSinceStartup;
            while ((double)Time.realtimeSinceStartup - (double)startTime < (double)time)
            {
                CameraEffects.SetSepia((object)handler, Mathf.Lerp(start, end, (Time.realtimeSinceStartup - startTime) / time));
                yield return (object)0;
            }
            if ((double)end == 0.0)
            CameraEffects.ClearSepia((object)handler);
        }
    }
}
