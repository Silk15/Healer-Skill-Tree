﻿
using System.Collections;
using ThunderRoad;
using UnityEngine;

namespace HealingTree
{
    public class PlayerMono : MonoBehaviour
    {
        public void Start()
        {
            Debug.Log("Hello");
        }
        public void Update()
        {
            if (Player.currentCreature != null)
            {
                Player.currentCreature.Heal(1f * Time.deltaTime);
            }
        }
    }
}
