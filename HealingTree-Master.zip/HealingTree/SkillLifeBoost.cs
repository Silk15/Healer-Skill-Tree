﻿
using System.Collections;
using ThunderRoad;
using ThunderRoad.Skill;
using ThunderRoad.Skill.Spell;
using UnityEngine;

namespace HealingTree
{
    public class SkillLifeBoost : SpellSkillData
    {
        public EffectData effectData;
        public EffectInstance effectInstance;
        public bool A, b, c, d, e, f, g = false;
        public override void OnSpellLoad(SpellData spell, SpellCaster caster = null)
        {
            base.OnSpellLoad(spell, caster);

            if (!(spell is SpellCastGravity spellCastGravity)) return;
            spellCastGravity.OnPushEvent -= SpellCastGravity_OnPushEvent;
            spellCastGravity.OnPushEvent += SpellCastGravity_OnPushEvent;
        }

        private void SpellCastGravity_OnPushEvent(SpellCastGravity spell, Vector3 pushVector, Collider[] colliders, int collidersCount)
        {
            Player.currentCreature.Heal(5);
        }
    }
}
