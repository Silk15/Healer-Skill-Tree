﻿
using UnityEngine;
using ThunderRoad;
using ThunderRoad.Skill;

namespace HealingTree
{
    public class SpellLightningMergeHeal : SpellMergeData 
    {
        public bool isCasting;
        EffectInstance effect;
        public float reviveRadius = 3;
        public override void Merge(bool active)
        {
            base.Merge(active);
            isCasting = active;
            if (active)
            {
                Player.currentCreature.locomotion.SetSpeedModifier(0.5);
            }
        }
        public override void FixedUpdate()
        {
            base.FixedUpdate();
            if (isCasting)
            {
                Collider[] sphereContacts = Physics.OverlapSphere(Player.local.transform.position, reviveRadius);
                foreach (Collider collider in sphereContacts)
                {
                    var creature = collider?.GetComponentInParent<Creature>();
                    if (creature != null && creature.isKilled && !creature.isPlayer)
                    {
                        creature.ResurrectMaxHealth();
                        creature.SetFaction(2);
                        creature.SetFaction(2);
                        creature.brain.Load(creature.brain.instance.id);
                        creature.Inflict("ElectrocuteBuff", this, 3, null, true);
                        creature.brain.instance.tree.blackboard.UpdateVariable("FollowTarget", Player.local.creature);
                        if (Player.currentCreature.HasSkill("Allyship"))
                        {
                            creature.SetDamageMultiplier(this, 1.3f);
                        }
                    }
                }
            }
            if (!isCasting)
            {
                Player.currentCreature.locomotion.RemoveSpeedModifier(this);
            }
        }
    }
}
