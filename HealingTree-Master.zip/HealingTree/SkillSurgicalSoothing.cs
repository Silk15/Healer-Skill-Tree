﻿using System;
using UnityEngine;
using ThunderRoad;

namespace HealingTree
{
    public class SkillSurgicalSoothing : SkillData
    {
        public override void OnSkillLoaded(SkillData skillData, Creature creature)
        {
            base.OnSkillLoaded(skillData, creature);
            Debug.Log("Deez");
        }
    }
}
