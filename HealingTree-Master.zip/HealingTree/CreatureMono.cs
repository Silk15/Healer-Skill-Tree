﻿
using System.Collections;
using ThunderRoad;
using UnityEngine;

namespace HealingTree
{
    public class CreatureMono : MonoBehaviour
    {
        public void Start()
        {
            Debug.Log("Hello");
        }

    }
}
