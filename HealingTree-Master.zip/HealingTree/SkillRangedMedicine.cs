﻿
using UnityEngine;
using ThunderRoad;
using ThunderRoad.Skill.Spell;
using ThunderRoad.Skill;
using System.Collections;

namespace HealingTree
{
    public class SkillRangedMedicine : SkillData
    {
        public bool imbuedWithHeal = false;
        public Damager damagerPierce;
        public override void OnSkillLoaded(SkillData skillData, Creature creature)
        {
            base.OnSkillLoaded(skillData, creature);
            EventManager.OnBowFireEvent += EventManager_OnBowFireEvent;
        }
        public override void OnSkillUnloaded(SkillData skillData, Creature creature)
        {
            base.OnSkillUnloaded(skillData, creature);
            EventManager.OnBowFireEvent -= EventManager_OnBowFireEvent;
            if (damagerPierce != null)
            {
                damagerPierce.OnPenetrateEvent -= Damager_OnPenetrateEvent;
            }
        }
        private void EventManager_OnBowFireEvent(RagdollHand hand, BowString bowString, Item arrow)
        {
            if (hand.creature.isPlayer)
            {
            foreach (Imbue imbue in arrow.imbues)
            {
                if (imbue.spellCastBase.id == "Healer")
                {
                    imbuedWithHeal = true;
                }
            }
            damagerPierce = arrow.GetComponentInChildren<Damager>();
            if (damagerPierce != null && imbuedWithHeal)
            {
                damagerPierce.OnPenetrateEvent += Damager_OnPenetrateEvent;
            }
            else return;
            }

        }
        private void Damager_OnPenetrateEvent(Damager damager, CollisionInstance collision)
        {
            var creature = collision?.targetColliderGroup?.GetComponentInParent<Creature>();
            if (creature != null && creature.GetComponent<CreatureMono>() != null && Player.currentCreature.HasSkill("CharismaOfTheCorpsman"))
            {
                SkillDiscombobulate.BrainToggle(creature, true, true);
                creature.SetFaction(2);
            }
            if (creature != null && creature.factionId == 2)
            {
                creature.Heal(collision.damageStruct.damage * 2);
            }
            if (creature != null && creature.factionId != 2 && creature.GetComponent<CreatureMono>() == null)
            {
                Player.currentCreature.Heal(collision.damageStruct.damage * 0.5f);
                if (!creature.isPlayer)
                {
                    SkillDiscombobulate.BrainToggle(creature, false, false);
                    creature.gameObject.AddComponent<CreatureMono>();
                }
            }
            damagerPierce.OnPenetrateEvent -= Damager_OnPenetrateEvent;
        }
    }
}
