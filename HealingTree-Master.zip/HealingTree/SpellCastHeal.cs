﻿
using UnityEngine;
using ThunderRoad;
using ThunderRoad.Skill;
using System.Collections;
using System.Collections.Generic;
using ThunderRoad.AI.Get;
using static ThunderRoad.BrainModuleStance;
using JetBrains.Annotations;
using System;
using ThunderRoad.Skill.Spell;

namespace HealingTree
{
    public class SpellCastHeal : SpellCastCharge 
    { 
        public List<Creature> creatures = new List<Creature>();
        public bool creatureGrabbed = false;
        public bool skillTriggeredMercy = false;
        public bool handsReleased = false;
        public bool somethingGrabbed = false;
        public bool creatureReset = false;
        public EffectInstance effect;
        public Light light;
        Color colorGlow = new Color(1, 0.4514318f, 0, 1);
        Color CurrentColor;
        Color BaseColor = new Color(0, 0, 0, 1);
        public Creature heldCreature;
        public Transform shootPoint;
        public ItemData itemShield;
        public float healing = 5;
        public float radius = 0.065f;
        public bool surgicalSoothingHeal = false;
        public float surgicalSoothingHealFactor = 5;
        public float lifeStealAmount = 0.6f;
        public bool timerHasNotExpired = false;
        public Creature heldMouthCreature;
        public SpellCastLightning lightningInstance;
        public List<Creature> allies = new List<Creature>();
        public override void OnSkillLoaded(SkillData skillData, Creature creature)
        {
            base.OnSkillLoaded(skillData, creature);
            creature.handLeft.OnGrabEvent += Hand_OnGrabEvent;
            creature.handRight.OnGrabEvent += Hand_OnGrabEvent;
            creature.handLeft.OnUnGrabEvent += Hand_OnUnGrabEvent;
            creature.handRight.OnUnGrabEvent += Hand_OnUnGrabEvent;
            EventManager.onLiquidConsumed += EventManager_onLiquidConsumed;
            EventManager.onCreatureKill += EventManager_onCreatureKill;
        }
        public override void OnSkillUnloaded(SkillData skillData, Creature creature)
        {
            base.OnSkillUnloaded(skillData, creature);
            creature.handLeft.OnGrabEvent -= Hand_OnGrabEvent;
            creature.handRight.OnGrabEvent -= Hand_OnGrabEvent;
            creature.handLeft.OnUnGrabEvent -= Hand_OnUnGrabEvent;
            creature.handRight.OnUnGrabEvent -= Hand_OnUnGrabEvent;
            EventManager.onLiquidConsumed -= EventManager_onLiquidConsumed;
            EventManager.onCreatureKill -= EventManager_onCreatureKill;
        }
        private void EventManager_onCreatureKill(Creature creature, Player player, CollisionInstance collisionInstance, EventTime eventTime)
        {
            if (!creature.isPlayer)
            {
                var liquid = creature.GetComponentInChildren<LiquidReceiver>();
                if (liquid != null)
                {
                    GameManager.local.StartCoroutine(EnableMouth(liquid));
                }
                foreach (Creature ally in allies)
                {
                    ally.brain.Load(ally.brain.instance.id);
                    ally.brain.instance.tree.blackboard.UpdateVariable("FollowTarget", Player.local.creature);
                }
            }
        }
        IEnumerator EnableMouth(LiquidReceiver liquid)
        {
            yield return new WaitForSeconds(1);
            liquid?.gameObject.SetActive(true);
            liquid.enabled = true;
        }
        private void EventManager_onLiquidConsumed(LiquidContainer liquidContainer, Creature consumer, EventTime eventTime)
        {
            if (!consumer.isPlayer && consumer.isKilled && Player.currentCreature.HasSkill("Resuscitation") && eventTime == EventTime.OnEnd)
            {
                consumer.ResurrectMaxHealth();
                SkillDiscombobulate.BrainToggle(consumer, false, false);
                consumer.gameObject.AddComponent<CreatureMono>();
            }
        }
        private void Hand_OnUnGrabEvent(Side side, Handle handle, bool throwing, EventTime eventTime)
        {
            if (Player.currentCreature.HasSkill("MedicInTheMist") && handle is HandleRagdoll && eventTime == EventTime.OnEnd)
            {
                foreach (Creature activeCreature in Creature.allActive)
                {
                    if (!activeCreature.isPlayer)
                    {
                        {
                            activeCreature.brain.instance.GetModule<BrainModuleMelee>().meleeEnabled = true;
                        }
                    }
                }
            }
            heldCreature = null;
            GameManager.local.StopCoroutine(Surrender());
        }
        private void Hand_OnGrabEvent(Side side, Handle handle, float axisPosition, HandlePose orientation, EventTime eventTime)
        {
            if (handle is HandleRagdoll && eventTime == EventTime.OnEnd && Player.currentCreature.HasSkill("MedicInTheMist"))
            {
                foreach (Creature activeCreature in Creature.allActive)
                {
                    if (!activeCreature.isPlayer)
                    {
                        activeCreature.brain.instance.GetModule<BrainModuleMelee>().meleeEnabled = false;
                    }
                }
            }
            if (handle is HandleRagdoll handleRagdoll && handleRagdoll.interactableId == "HumanHeadNeck" && eventTime == EventTime.OnEnd && Player.currentCreature.HasSkill("Submission"))
            {
                heldCreature = handleRagdoll.GetComponentInParent<Creature>();
                GameManager.local.StartCoroutine(Surrender());
                var brainId = heldCreature.brain.instance.id;
            }
            else if (handle is HandleRagdoll handleRagdollMouth && handleRagdollMouth.interactableId == "HumanHeadMouth" && eventTime == EventTime.OnEnd && Player.currentCreature.HasSkill("Non-LethalTakedown"))
            {
                heldMouthCreature = handleRagdollMouth.GetComponentInParent<Creature>();
                GameManager.local.StartCoroutine(Sleep());
            }
        }
        IEnumerator Surrender()
            {
                yield return new WaitForSeconds(3);
                if (heldCreature != null)
                {
                    heldCreature.SetFaction(2);
                    heldCreature.PlayAnimation("HumanCower");
                    heldCreature.handLeft.TryRelease();
                    heldCreature.handRight.TryRelease();
                    heldCreature.brain.instance.GetModule<BrainModuleLookAt>().StopLookAt(true);
                    heldCreature.brain.instance.GetModule<BrainModuleLookAt>().actionLock = true;
                    heldCreature.brain.instance.GetModule<BrainModuleMove>().allowMove = false;
                    heldCreature.countTowardsMaxAlive = false;
                    heldCreature.brain.Load(heldCreature.brain.instance.id);
                    allies.Add(heldCreature);
                    foreach (WaveSpawner spawner in WaveSpawner.instances)
                    {
                        spawner.spawnedCreatures?.Remove(heldCreature);
                    }

            }
            }
        IEnumerator Sleep()
        {
            yield return new WaitForSeconds(3);
            if (heldCreature != null)
            {
                SkillDiscombobulate.BrainToggle(heldMouthCreature, false, false);
                heldCreature.brain.instance.GetModule<BrainModuleSpeak>().Play("death", true, true);
                heldCreature.gameObject.AddComponent<CreatureMono>();
                heldCreature.handLeft.TryRelease();
                heldCreature.handRight.TryRelease();
                yield return new WaitForSeconds(30);
                SkillDiscombobulate.BrainToggle(heldMouthCreature, true, true);

            }
        }

        public override bool OnImbueCollisionStart(CollisionInstance collisionInstance)
        {
            var creature = collisionInstance.targetColliderGroup.GetComponentInParent<Creature>();
            if (creature != null && !creature.isKilled && collisionInstance?.damageStruct.damageType == DamageType.Pierce || collisionInstance?.damageStruct.damageType == DamageType.Slash)
            {
                Player.currentCreature.Heal(collisionInstance.damageStruct.damage *+ lifeStealAmount);
            }
            return base.OnImbueCollisionStart(collisionInstance);
        }
        public override void FixedUpdateCaster()
        {
            base.FixedUpdateCaster();
            if (spellCaster.isFiring)
            {
                Collider[] sphereContacts = Physics.OverlapSphere(spellCaster.magicSource.position, radius);
                foreach (Collider collider in sphereContacts)
                {
                    var creature = collider?.GetComponentInParent<Creature>();
                    creature?.Heal(healing * Time.fixedDeltaTime);
                    if (creature != null && creature.isPlayer && Player.currentCreature.HasSkill("WeightlessRegeneration"))
                    {
                        creature.Inflict("Floating", this, 5, null, true);
                    }
                    if (creature != null && Player.currentCreature.HasSkill("Therapy"))
                    {
                        creature.mana.RegenFocus(5 * Time.fixedDeltaTime);
                    }
                    if (creature != null && creature.HasAnyStatus() && !creature.isPlayer && Player.currentCreature.HasSkill("SurgicalSoothing"))
                    {
                        creature.ClearAllStatus();
                        SkillDiscombobulate.BrainToggle(creature, false, false);
                        creature.ragdoll.SetState(Ragdoll.State.Destabilized);
                        creature.gameObject.AddComponent<CreatureMono>();
                        if (!creatures.Contains(creature))
                        {
                            if (surgicalSoothingHeal)
                            {
                                Player.currentCreature.Heal(surgicalSoothingHealFactor);
                            }
                            creatures.Add(creature);
                            GameManager.local.StartCoroutine(WakeCreature(creature));
                        }
                    }
                    if (creature != null && !creature.isPlayer && creature.currentHealth <= 20 && Player.currentCreature.HasSkill("HorsDeCombat"))
                    {
                        SkillDiscombobulate.BrainToggle(creature, false, false);
                        creature?.ragdoll?.SetState(Ragdoll.State.Destabilized);
                        creature?.gameObject?.AddComponent<CreatureMono>();
                        creature.countTowardsMaxAlive = false;
                    }
                    if (creature != null && !creature.isPlayer && Player.currentCreature.HasSkill("CharismaOfTheCorpsman"))
                    {
                        var mono = creature.GetComponent<CreatureMono>();
                        if (mono != null)
                        {
                            SkillDiscombobulate.BrainToggle(creature, true, true);
                            creature.SetFaction(2);
                            if (creature.GetComponent<ResetMono>() == null)
                            {
                                creature.brain.instance.tree.blackboard.UpdateVariable("FollowTarget", Player.local.creature);
                                creature.gameObject.AddComponent<ResetMono>();
                                creature.brain.Load(creature.brain.instance.id);
                                allies.Add(creature);
                                if (Player.currentCreature.HasSkill("Allyship"))
                                {
                                    creature.SetDamageMultiplier(this, 0.5f);
                                }
                            }

                        }
                    }
                }
            }
            if (Player.currentCreature.HasSkill("MedicInTheMist"))
            {
                foreach (Creature activeCreature in Creature.allActive)
                {
                    if (!activeCreature.isPlayer)
                    {
                        activeCreature.brain.instance.GetModule<BrainModulePatrol>().viewRadius = 1;
                        activeCreature.brain.instance.GetModule<BrainModulePatrol>().viewAngle = 30;
                    }
                }
            }  
        }
        IEnumerator WakeCreature(Creature creature)
        {
            yield return new WaitForSeconds(15);
            SkillDiscombobulate.BrainToggle(creature, true, true);
        }
    }
}
