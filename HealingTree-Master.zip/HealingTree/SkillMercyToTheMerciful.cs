﻿using UnityEngine;
using ThunderRoad;
using System.Collections;

namespace HealingTree
{
    public class SkillMercyToTheMerciful : SkillData
    {
        public bool skillTriggered = false;
        protected EffectData startEffectData;
        public override void OnSkillLoaded(SkillData skillData, Creature creature)
        {
            base.OnSkillLoaded(skillData, creature);
            EventManager.onPossess += EventManager_onPossess;
            EventManager.onUnpossess += EventManager_onUnpossess;
            startEffectData = Catalog.GetData<EffectData>("SecondWindStart");
        }
        public override void OnSkillUnloaded(SkillData skillData, Creature creature)
        {
            base.OnSkillUnloaded(skillData, creature);
            EventManager.onPossess -= EventManager_onPossess;
            EventManager.onUnpossess -= EventManager_onUnpossess;
            Player.currentCreature.OnDamageEvent -= CurrentCreature_OnDamageEvent;
            Player.currentCreature.handLeft.OnGrabEvent -= Hand_OnGrabEvent;
            Player.currentCreature.handRight.OnGrabEvent -= Hand_OnGrabEvent;
            EventManager.onCreatureHit -= EventManager_onCreatureHit;
        }
        private void EventManager_onPossess(Creature creature, EventTime eventTime)
        {
            if (eventTime == EventTime.OnEnd)
            {
                Player.currentCreature.OnDamageEvent += CurrentCreature_OnDamageEvent;
                Player.currentCreature.handLeft.OnGrabEvent += Hand_OnGrabEvent;
                Player.currentCreature.handRight.OnGrabEvent += Hand_OnGrabEvent;
                EventManager.onCreatureHit += EventManager_onCreatureHit;
            }
        }
        private void EventManager_onUnpossess(Creature creature, EventTime eventTime)
        {
            if (eventTime == EventTime.OnEnd)
            {
                Player.currentCreature.OnDamageEvent -= CurrentCreature_OnDamageEvent;
                Player.currentCreature.handLeft.OnGrabEvent -= Hand_OnGrabEvent;
                Player.currentCreature.handRight.OnGrabEvent -= Hand_OnGrabEvent;
                EventManager.onCreatureHit -= EventManager_onCreatureHit;
            } 
        }
        private void EventManager_onCreatureHit(Creature creature, CollisionInstance collisionInstance, EventTime eventTime)
        {
            if (!creature.isPlayer && eventTime == EventTime.OnEnd && skillTriggered)
            {
                foreach (Creature activeCreature in Creature.allActive)
                {
                    if (!activeCreature.isPlayer)
                    {
                        activeCreature.brain.instance.GetModule<BrainModuleMelee>().meleeEnabled = false;
                    }
                }
            }
        }
        private void Hand_OnGrabEvent(Side side, Handle handle, float axisPosition, HandlePose orientation, EventTime eventTime)
        {
            if (skillTriggered && handle?.item?.data?.type == ItemData.Type.Weapon)
            {
                foreach (Creature activeCreature in Creature.allActive)
                {
                    if (!activeCreature.isPlayer)
                    {
                        activeCreature.brain.instance.GetModule<BrainModuleMelee>().meleeEnabled = true;
                        CameraEffects.ClearAllSepia();
                    }
                }
            }
        }
        private void CurrentCreature_OnDamageEvent(CollisionInstance collisionInstance, EventTime eventTime)
        {
            if (eventTime == EventTime.OnEnd && Player.currentCreature._currentHealth <= 20 && !skillTriggered)
            {
                Debug.Log(Player.currentCreature._currentHealth);
                Player.currentCreature.handLeft.UnGrab(false);
                Player.currentCreature.handRight.UnGrab(false);
                foreach (Creature activeCreature in Creature.allActive)
                {
                    if (!activeCreature.isPlayer)
                    {
                        activeCreature.brain.instance.GetModule<BrainModuleMelee>().meleeEnabled = false;
                    }
                }
                skillTriggered = true;
                GameManager.local.StartCoroutine(skillReset());
                GameManager.local.StartCoroutine(SepiaRoutine(0.0f, 1f, 0.3f));
            }
        }
        public IEnumerator SepiaRoutine(float start, float end, float time)
        {
            SkillMercyToTheMerciful handler = this;
            EffectInstance startEffect = startEffectData.Spawn(Player.currentCreature.ragdoll.targetPart.transform);
            float startTime = Time.realtimeSinceStartup;
            while ((double)Time.realtimeSinceStartup - (double)startTime < (double)time)
            {
                CameraEffects.SetSepia((object)handler, Mathf.Lerp(start, end, (Time.realtimeSinceStartup - startTime) / time));
                yield return (object)0;
            }
            if ((double)end == 0.0)
            CameraEffects.ClearSepia((object)handler);
        }
        IEnumerator skillReset()
        {
            yield return new WaitForSeconds(60);
            skillTriggered = false;
            CameraEffects.ClearAllSepia();
        }
    }
}
