﻿
using System.Collections;
using System.Security.Permissions;
using ThunderRoad;
using UnityEngine;

namespace HealingTree
{
    public class SkillHealingGrasp : SkillData
    {
        public override void OnSkillLoaded(SkillData skillData, Creature creature)
        {
            base.OnSkillLoaded(skillData, creature);
        }
    }
}
