﻿
using UnityEngine;
using ThunderRoad;
using ThunderRoad.Skill;

namespace HealingTree
{
    public class StatusDataHealing : StatusData 
    {
    }
}
