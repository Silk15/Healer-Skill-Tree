﻿
using UnityEngine;
using ThunderRoad;
using System;
using System.Collections.Generic;
using System.Collections;

namespace HealingTree
{
    public class SpellFireMergeHeal : SpellMergeData
    {
        public bool isCasting;
        EffectInstance effect;
        public float healing = 7;
        public float healingRadius = 1;
        public Item mergeItem = null;
        public bool skillHasntTriggered = true;
        public override void Merge(bool active)
        {
            base.Merge(active);
            isCasting = active;
        }
        public override void FixedUpdate()
        {
            base.FixedUpdate();
            if (mergeItem != null)
            {
                Collider[] sphereContacts = Physics.OverlapSphere(Player.local.transform.position, healingRadius);
                foreach (Collider collider in sphereContacts)
                {
                    var creature = collider?.GetComponentInParent<Creature>();
                    if (creature.isPlayer && skillHasntTriggered)
                    {
                        creature.Inflict("Burning", this, 10, heat: 100f, true);
                        Debug.Log(creature);
                        Debug.Log("Status Inflicted");
                        Player.currentCreature.AddJointForceMultiplier(this, 10, 10);
                        Player.currentCreature.SetDamageMultiplier(this, 10);
                        Player.currentCreature.currentLocomotion.SetAllSpeedModifiers(this, 1.8f);
                        GameManager.local.StartCoroutine(DisableStrength());
                        skillHasntTriggered = false;
                    }
                }
            }
        }
        IEnumerator DisableStrength()
        {
            yield return new WaitForSeconds(10);
            skillHasntTriggered = true;
            Player.currentCreature.AddJointForceMultiplier(this, 1, 1);
            Player.currentCreature.SetDamageMultiplier(this, 1);
            Player.currentCreature.currentLocomotion.SetAllSpeedModifiers(this, 1);
        }
    }
}
