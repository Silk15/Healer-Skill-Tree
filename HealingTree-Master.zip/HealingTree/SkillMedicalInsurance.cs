﻿
using ThunderRoad;

namespace HealingTree
{
    public class SkillMedicalInsurance : SkillData
    {
        public LiquidData data;
        public ItemData potion;
        public override void OnSkillLoaded(SkillData skillData, Creature creature)
        {
            base.OnSkillLoaded(skillData, creature);
            potion = Catalog.GetData<ItemData>("PotionHealth");
            potion.value = 60;
        }
        public override void OnSkillUnloaded(SkillData skillData, Creature creature)
        {
            base.OnSkillUnloaded(skillData, creature);
            potion.value = 123;
        }
    }
}
