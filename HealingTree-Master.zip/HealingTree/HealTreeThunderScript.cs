﻿using UnityEngine;
using System.Collections;
using ThunderRoad;
using System.Collections.Generic;

namespace HealingTree
{
    public class HealTree : ThunderScript
    {
        public Creature leftCreature;
        public Creature rightCreature;
        public float leftTimer = 0f;
        public float rightTimer = 0f;
        public List<Creature> creatures = new List<Creature>();
        public override void ScriptEnable()
        {
            base.ScriptEnable();
            EventManager.onPossess += EventManager_onPossess;
        }
        private void EventManager_onPossess(Creature creature, EventTime eventTime)
        {
            creature.handLeft.OnGrabEvent += Hand_OnGrabEvent;
            creature.handRight.OnGrabEvent += Hand_OnGrabEvent;
            creature.handLeft.OnUnGrabEvent += Hand_OnUnGrabEvent;
            creature.handRight.OnUnGrabEvent += Hand_OnUnGrabEvent;
        }
        public override void ScriptUpdate()
        {
            base.ScriptUpdate();
            if (leftCreature != null && Time.time - leftTimer >= 3f && !leftCreature.isKilled && !creatures.Contains(leftCreature) && Player.currentCreature.HasSkill("SkillSubmission"))
            {
                leftCreature.PlayAnimation("HumanCower");
                leftCreature.SetFaction(2);
                leftCreature.handLeft.TryRelease();
                leftCreature.handRight.TryRelease();
                leftCreature.brain.instance.GetModule<BrainModuleLookAt>().StopLookAt(true);
                leftCreature.brain.instance.GetModule<BrainModuleLookAt>().actionLock = true;
                leftCreature.brain.instance.GetModule<BrainModuleMove>().allowMove = false;
                leftCreature.countTowardsMaxAlive = false;
                foreach (WaveSpawner spawner in WaveSpawner.instances)
                    {
                    spawner.spawnedCreatures?.Remove(leftCreature);
                    }
                creatures.Add(leftCreature);

            }
            if (rightCreature != null && Time.time - rightTimer >= 3f && !rightCreature.isKilled && !creatures.Contains(rightCreature) && Player.currentCreature.HasSkill("SkillSubmission"))
            {
                rightCreature.PlayAnimation("HumanCower");
                rightCreature.SetFaction(2);
                rightCreature.handLeft.TryRelease();
                rightCreature.handRight.TryRelease();
                rightCreature.brain.instance.GetModule<BrainModuleLookAt>().StopLookAt(true);
                rightCreature.brain.instance.GetModule<BrainModuleLookAt>().actionLock = true;
                rightCreature.brain.instance.GetModule<BrainModuleMove>().allowMove = false;
                foreach (WaveSpawner spawner in WaveSpawner.instances)
                {
                    spawner.spawnedCreatures?.Remove(rightCreature);
                }
                creatures.Add(rightCreature);
            }
        }
        private void Hand_OnUnGrabEvent(Side side, Handle handle, bool throwing, EventTime eventTime)
        {
            if (side == Side.Left)
            {
                leftCreature = null;
            }
            else
            {
                rightCreature = null;
            }
        }
        private void Hand_OnGrabEvent(Side side, Handle handle, float axisPosition, HandlePose orientation, EventTime eventTime)
        {
            if (handle is HandleRagdoll handleRagdoll && handleRagdoll.interactableId == "HumanHeadNeck" && eventTime == EventTime.OnEnd)
            {
                if (side == Side.Left)
                {
                    leftCreature = handleRagdoll.ragdollPart.ragdoll.creature;
                    leftTimer = Time.time;
                }
                else
                {
                    rightCreature = handleRagdoll.ragdollPart.ragdoll.creature;
                    rightTimer = Time.time;
                }
            }
        }
    }
}
