﻿
using UnityEngine;
using ThunderRoad;
using ThunderRoad.Skill.Spell;
using ThunderRoad.Skill;
using System.Collections;

namespace HealingTree
{
    public class SkillPaciFist : SkillSpellPunch
    {
        public float healing = 0.7f;
        public bool doHealing = true;
        public float sleepDuration = 10;
        public bool cooldownHasExpired = true;
        public override void OnSkillLoaded(SkillData skillData, Creature creature)
        {
            base.OnSkillLoaded(skillData, creature);
            Debug.Log("SkillPaciFist Unlocked");
        }
        public override void OnPunchHit(RagdollHand hand, CollisionInstance hit, bool fist)
        {
            base.OnPunchHit(hand, hit, fist);
            if (!fist) return;
            var creature = hit?.targetColliderGroup?.GetComponentInParent<Creature>();
            if (creature != null && !creature.isKilled && !creature.isPlayer && cooldownHasExpired)
            {
                creature.gameObject.AddComponent<CreatureMono>();
                SkillDiscombobulate.BrainToggle(creature, false, false);
                creature.ragdoll.SetState(Ragdoll.State.Destabilized);
                GameManager.local.StartCoroutine(Wake(creature));
                if (doHealing)
                {
                    Player.currentCreature.Heal(hit.damageStruct.damage *+ healing);
                }
                cooldownHasExpired = false;
                GameManager.local.StartCoroutine(Cooldown());
            }
        }
        IEnumerator Cooldown()
        {
            yield return new WaitForSeconds(cooldown);
            cooldownHasExpired = true;
        }
        IEnumerator Wake(Creature creature)
        {
            yield return new WaitForSeconds(sleepDuration);
            SkillDiscombobulate.BrainToggle(creature, true, true);
        }
    }
}
