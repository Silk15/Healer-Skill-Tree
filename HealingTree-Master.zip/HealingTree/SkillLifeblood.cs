﻿
using JetBrains.Annotations;
using System.Collections;
using ThunderRoad;
using ThunderRoad.Skill;
using ThunderRoad.Skill.Spell;
using UnityEngine;

namespace HealingTree
{
    public class SkillLifeblood : SkillData
    {
        public override void OnSkillLoaded(SkillData skillData, Creature creature)
        {
            base.OnSkillLoaded(skillData, creature);
            EventManager.onPossess += EventManager_onPossess;
        }
        public override void OnSkillUnloaded(SkillData skillData, Creature creature)
        {
            base.OnSkillUnloaded(skillData, creature);
            EventManager.onPossess -= EventManager_onPossess;
        }

        private void EventManager_onPossess(Creature creature, EventTime eventTime)
        { 
            Player.currentCreature.gameObject.AddComponent<PlayerMono>();
        }
    }
}
