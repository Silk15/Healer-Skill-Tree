﻿
using System.Collections;
using ThunderRoad;
using ThunderRoad.Skill;
using ThunderRoad.Skill.Spell;
using UnityEngine;

namespace HealingTree
{
    public class SkillLifebolt : SpellSkillData
    {
        public EffectData effectData;
        public EffectInstance effectInstance;
        public override void OnSpellLoad(SpellData spell, SpellCaster caster = null)
        {
            base.OnSpellLoad(spell, caster);

            if (!(spell is SpellCastLightning spellCastLightning)) return;
            spellCastLightning.OnBoltHitColliderGroupEvent -= SpellCastLightning_OnBoltHitColliderGroupEvent;
            spellCastLightning.OnBoltHitColliderGroupEvent += SpellCastLightning_OnBoltHitColliderGroupEvent;
        }
        private void SpellCastLightning_OnBoltHitColliderGroupEvent(SpellCastLightning spell, ColliderGroup colliderGroup, Vector3 position, Vector3 normal, Vector3 velocity, float intensity, ColliderGroup source, System.Collections.Generic.HashSet<ThunderEntity> seenEntities)
        {
            Catalog.GetData<EffectData>("HitImbueHealer").Spawn(position, Quaternion.LookRotation(normal, Vector3.up), colliderGroup: colliderGroup);
            var creature = colliderGroup.GetComponentInParent<Creature>();
            if (creature != null)
            {
                Player.currentCreature.Heal(1);
            }
        }
    }
}
