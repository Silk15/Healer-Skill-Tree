﻿
using System.Collections;
using ThunderRoad;
using ThunderRoad.Skill;
using ThunderRoad.Skill.Spell;
using UnityEngine;

namespace HealingTree
{
    public class SkillCauterise : SpellSkillData
    {
        public override void OnSpellLoad(SpellData spell, SpellCaster caster = null)
        {
            base.OnSpellLoad(spell, caster);
            if (!(spell is SpellCastProjectile spellCastProjectile)) return;
            spellCastProjectile.OnGripEndEvent -= SpellCastProjectile_OnGripEndEvent;
            spellCastProjectile.OnGripEndEvent += SpellCastProjectile_OnGripEndEvent;
        }

        private void SpellCastProjectile_OnGripEndEvent(SpellCastCharge spell)
        {
            Player.currentCreature.Heal(5);
        }
    }
}
